#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_APPLIANCES 50
#define NAME_LEN 50
#define DATA_FILE "data/electricity.txt"

typedef struct {
    char name[NAME_LEN];
    float power;
    float hoursPerDay;
    int days;
    float units;
} Appliance;

Appliance appliances[MAX_APPLIANCES];
int count = 0;
float ratePerUnit = 6.0f;

/* Calculate monthly electricity consumption in kWh (units). */
float calculateUnits(float power, float hoursPerDay, int days) {
    return (power * hoursPerDay * days) / 1000.0f;
}

void addAppliance(void) {
    if (count >= MAX_APPLIANCES) {
        printf("\nMaximum appliance limit reached.\n");
        return;
    }

    printf("\nEnter appliance name: ");
    scanf(" %49[^\n]", appliances[count].name);

    printf("Enter power rating (Watts): ");
    scanf("%f", &appliances[count].power);

    printf("Enter usage hours per day: ");
    scanf("%f", &appliances[count].hoursPerDay);

    printf("Enter number of days used per month: ");
    scanf("%d", &appliances[count].days);

    appliances[count].units = calculateUnits(
        appliances[count].power,
        appliances[count].hoursPerDay,
        appliances[count].days
    );

    count++;
    printf("\nAppliance added successfully!\n");
}

void displayAppliances(void) {
    int i;

    if (count == 0) {
        printf("\nNo appliances added yet.\n");
        return;
    }

    printf("\n================ APPLIANCE DETAILS ================\n");
    printf("%-20s %-10s %-10s %-8s %-10s\n",
           "Appliance", "Power(W)", "Hours", "Days", "Units");

    for (i = 0; i < count; i++) {
        printf("%-20s %-10.1f %-10.1f %-8d %-10.2f\n",
               appliances[i].name,
               appliances[i].power,
               appliances[i].hoursPerDay,
               appliances[i].days,
               appliances[i].units);
    }
}

float getTotalUnits(void) {
    float total = 0.0f;
    int i;

    for (i = 0; i < count; i++) {
        total += appliances[i].units;
    }

    return total;
}

void showBill(void) {
    float totalUnits;
    float bill;

    if (count == 0) {
        printf("\nNo appliance data available.\n");
        return;
    }

    printf("\nEnter electricity rate per unit (Rs): ");
    scanf("%f", &ratePerUnit);

    totalUnits = getTotalUnits();
    bill = totalUnits * ratePerUnit;

    printf("\n========== ELECTRICITY BILL ==========\n");
    printf("Total consumption : %.2f units\n", totalUnits);
    printf("Rate per unit     : Rs. %.2f\n", ratePerUnit);
    printf("Estimated bill    : Rs. %.2f\n", bill);
}

void showHighestUsage(void) {
    int i, highest = 0;

    if (count == 0) {
        printf("\nNo appliance data available.\n");
        return;
    }

    for (i = 1; i < count; i++) {
        if (appliances[i].units > appliances[highest].units) {
            highest = i;
        }
    }

    printf("\nHighest consuming appliance: %s\n", appliances[highest].name);
    printf("Monthly consumption: %.2f units\n", appliances[highest].units);
}

void rankAppliances(void) {
    Appliance temp[MAX_APPLIANCES];
    Appliance swap;
    int i, j;

    if (count == 0) {
        printf("\nNo appliance data available.\n");
        return;
    }

    for (i = 0; i < count; i++) {
        temp[i] = appliances[i];
    }

    for (i = 0; i < count - 1; i++) {
        for (j = 0; j < count - 1 - i; j++) {
            if (temp[j].units < temp[j + 1].units) {
                swap = temp[j];
                temp[j] = temp[j + 1];
                temp[j + 1] = swap;
            }
        }
    }

    printf("\n========== APPLIANCE RANKING ==========\n");
    for (i = 0; i < count; i++) {
        printf("%d. %-20s %.2f units\n",
               i + 1, temp[i].name, temp[i].units);
    }
}

void savingSuggestions(void) {
    int i;
    float total;

    if (count == 0) {
        printf("\nNo appliance data available.\n");
        return;
    }

    total = getTotalUnits();

    printf("\n========== ENERGY-SAVING SUGGESTIONS ==========\n");

    for (i = 0; i < count; i++) {
        float percentage = (appliances[i].units / total) * 100.0f;

        if (percentage >= 30.0f) {
            printf("- %s uses %.1f%% of your recorded consumption.\n",
                   appliances[i].name, percentage);
            printf("  Consider reducing its usage time where possible.\n");
        }
    }

    printf("- Switch off lights and appliances when they are not needed.\n");
    printf("- Prefer energy-efficient appliances when replacing old ones.\n");
    printf("- Monitor high-power appliances such as ACs, heaters and irons.\n");
}

void reductionTarget(void) {
    float target, total, saving, targetUnits;

    if (count == 0) {
        printf("\nNo appliance data available.\n");
        return;
    }

    total = getTotalUnits();

    printf("\nEnter desired reduction percentage: ");
    scanf("%f", &target);

    if (target < 0 || target > 100) {
        printf("Please enter a value between 0 and 100.\n");
        return;
    }

    saving = total * target / 100.0f;
    targetUnits = total - saving;

    printf("\n========== REDUCTION TARGET ==========\n");
    printf("Current usage : %.2f units\n", total);
    printf("Target        : %.1f%% reduction\n", target);
    printf("Units to save : %.2f units\n", saving);
    printf("New target    : %.2f units\n", targetUnits);
}

void saveData(void) {
    FILE *file;
    int i;

    file = fopen(DATA_FILE, "w");

    if (file == NULL) {
        printf("\nUnable to save data. Make sure the 'data' folder exists.\n");
        return;
    }

    fprintf(file, "SMART ELECTRICITY ANALYZER DATA\n");
    fprintf(file, "Rate per unit: %.2f\n\n", ratePerUnit);

    for (i = 0; i < count; i++) {
        fprintf(file, "%s|%.2f|%.2f|%d|%.2f\n",
                appliances[i].name,
                appliances[i].power,
                appliances[i].hoursPerDay,
                appliances[i].days,
                appliances[i].units);
    }

    fclose(file);
    printf("\nData saved successfully to %s\n", DATA_FILE);
}

void menu(void) {
    int choice;

    do {
        printf("\n\n===============================================\n");
        printf("       SMART ELECTRICITY USAGE ANALYZER\n");
        printf("===============================================\n");
        printf("1. Add Appliance\n");
        printf("2. View All Appliances\n");
        printf("3. Calculate Estimated Bill\n");
        printf("4. Show Highest-Usage Appliance\n");
        printf("5. Rank Appliances by Consumption\n");
        printf("6. Energy-Saving Suggestions\n");
        printf("7. Set Consumption Reduction Target\n");
        printf("8. Save Data\n");
        printf("9. Exit\n");
        printf("-----------------------------------------------\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addAppliance();
                break;
            case 2:
                displayAppliances();
                break;
            case 3:
                showBill();
                break;
            case 4:
                showHighestUsage();
                break;
            case 5:
                rankAppliances();
                break;
            case 6:
                savingSuggestions();
                break;
            case 7:
                reductionTarget();
                break;
            case 8:
                saveData();
                break;
            case 9:
                printf("\nThank you for using Smart Electricity Usage Analyzer!\n");
                break;
            default:
                printf("\nInvalid choice. Please try again.\n");
        }
    } while (choice != 9);
}

int main(void) {
    printf("Welcome to Smart Electricity Usage Analyzer!\n");
    menu();
    return 0;
}
