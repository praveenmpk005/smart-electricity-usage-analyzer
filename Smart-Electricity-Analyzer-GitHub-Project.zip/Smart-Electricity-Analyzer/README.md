# ⚡ Smart Electricity Usage Analyzer

A beginner-friendly C project that analyzes household electricity consumption and estimates the monthly electricity bill.

## 🚀 Features

- Add household appliances
- Calculate appliance-wise monthly electricity consumption
- Calculate total electricity usage in units (kWh)
- Estimate the electricity bill
- Find the highest-consuming appliance
- Rank appliances by electricity consumption
- Generate energy-saving suggestions
- Set a target for reducing electricity consumption
- Save appliance data using C file handling

## 🧮 Formula

**Monthly Units = Power (Watts) × Hours per Day × Days per Month ÷ 1000**

**Estimated Bill = Total Units × Rate per Unit**

## 💻 C Concepts Used

- Variables and data types
- `if/else`
- `switch`
- Loops
- Functions
- Arrays
- Structures (`struct`)
- Strings
- Sorting
- File handling
- Menu-driven programming

## 📁 Project Structure

```text
Smart-Electricity-Analyzer/
├── src/
│   └── main.c
├── data/
│   └── electricity.txt
├── README.md
├── Smart_Electricity_Analyzer_Project.pdf
└── LICENSE
```

## ▶️ How to Run

Make sure GCC is installed.

From the project folder:

```bash
gcc src/main.c -o electricity_analyzer
```

Run on Windows:

```bash
electricity_analyzer.exe
```

Or in VS Code terminal:

```bash
gcc src/main.c -o electricity_analyzer.exe
./electricity_analyzer.exe
```

## 📌 Example

If a 1500 W appliance is used for 2 hours per day for 30 days:

```text
1500 × 2 × 30 ÷ 1000 = 90 units
```

## 🔮 Future Improvements

- Monthly usage comparison
- Graphical dashboard using Python
- Database support
- IoT-based real-time electricity monitoring
- AI-based consumption prediction
- Web/mobile dashboard

## 👨‍💻 Author

Praveen Kumar

---

⭐ If you find this project useful, consider giving the repository a star!
